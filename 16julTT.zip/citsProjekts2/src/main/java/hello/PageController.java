package hello;

import java.sql.SQLException;
//import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class PageController {
	
	public static DatabaseController db;
	
    @GetMapping("/greeting")
    public String greeting(@RequestParam(name="name", required=false, defaultValue="World") String name, Model model) throws ClassNotFoundException, SQLException {
        model.addAttribute("name", name);        
        return "greeting";
    }
    @GetMapping("/admin")
    public String greeting(Model model) throws ClassNotFoundException, SQLException {      
        return "admin";
    }
    
    @GetMapping("/getMovies")
    public String getMovies(Model model) throws ClassNotFoundException, SQLException {
    	
    	db=new DatabaseController("db_cbs", "springuser", "parole");
    	
        model.addAttribute("filmas", db.getFilmas());
        return "getMovies";
    }
    @GetMapping("/index1")
    public String index1(Model model) throws ClassNotFoundException, SQLException {
    	
    	db=new DatabaseController("db_cbs", "springuser", "parole");
    	
        model.addAttribute("cinemas", db.getCinemas());
        //model.addAttribute("filmas", db.getShows());
        return "index1";
    }
    
    @GetMapping("/cinemaList")
    public String cinemaList(Model model) throws ClassNotFoundException, SQLException{
    	db=new DatabaseController("db_cbs", "springuser", "parole");
    	model.addAttribute("cinemas", db.getCinemas());
    	return "cinemaList";
    }
    
    @GetMapping("/getShows")
    public String getShows(@RequestParam(name="cinemaID", required=true, defaultValue="1") Cinemas cinema, String cinemaID, Model model) throws ClassNotFoundException, SQLException{
    	db=new DatabaseController("db_cbs", "springuser", "parole");
    	model.addAttribute("cinemas", db.getCinemas());
    	model.addAttribute("shows", db.getShows(Integer.parseInt(cinemaID)));
    	return "getShows";
    }
    @GetMapping("/getShow")
    public String getShow(@RequestParam(name="show_id", required=true, defaultValue="1") String show_id, Model model) throws ClassNotFoundException, SQLException{
    	db=new DatabaseController("db_cbs", "springuser", "parole");
    	model.addAttribute("show", db.getShow(show_id));
    	return "getShow";
    }
    @GetMapping("/getRooms")
    public String getRooms(@RequestParam(name="cinemaID", required=true, defaultValue="1") String cinemaID, Model model) throws ClassNotFoundException, SQLException{
    	db=new DatabaseController("db_cbs", "springuser", "parole");
    	model.addAttribute("cinemas", db.getCinemas());
    	model.addAttribute("rooms", db.getRooms(Integer.parseInt(cinemaID)));
    	return "getRooms";
    }

    @PostMapping(value = "/getRooms")
    public String getAdminRooms(@RequestParam(name="cinemaID", required=true, defaultValue="1") String cinemaID, Model model) throws ClassNotFoundException, SQLException{
    	db=new DatabaseController("db_cbs", "springuser", "parole");
       	model.addAttribute("cinemas", db.getCinemas());
    	model.addAttribute("rooms", db.getRooms(Integer.parseInt(cinemaID)));
     	return "/getRooms";
    }
    
    
    
    @GetMapping("/addMovie")
    public String addMovie(Model model) {
    	model.addAttribute("movie", new Movies());
    	return "addMovie";
    }
    
    @PostMapping("/addMovie")
    public String adminAddMovie(@ModelAttribute Movies movie) throws ClassNotFoundException, SQLException {
     	db=new DatabaseController("db_cbs", "springuser", "parole");
    	db.AddMovie(movie.getName(), movie.getGenre());
    	return "redirect:/getMovies";
    }
    
    @GetMapping("/addCinema")
    public String addCinema(Model model) {
    	model.addAttribute("cinema", new Cinemas());
    	return "addCinema";
    }
    
    @PostMapping(value = "/addCinema")
    public String adminAddCinema(@ModelAttribute Cinemas cinema) throws ClassNotFoundException, SQLException{
     	
    	db=new DatabaseController("db_cbs", "springuser", "parole");
    	db.AddCinema(cinema.getName(), cinema.getLatitude(), cinema.getLatitude());
     	
     	return "redirect:/cinemaList";
    }
    
    @GetMapping("/addRoom")
    public String addRoom(Model model) throws ClassNotFoundException, SQLException {
    	db=new DatabaseController("db_cbs", "springuser", "parole");
    	model.addAttribute("room", new Rooms());
        model.addAttribute("cinemas", db.getCinemas());
    	return "addRoom";
    }
 
    @PostMapping(value = "/addRoom")
    public String adminAddRoom(@ModelAttribute Rooms room, Cinemas cinema, String selectCinema) throws ClassNotFoundException, SQLException{
    	//System.out.println(selectedCinema.getCinema_id());
    	db=new DatabaseController("db_cbs", "springuser", "parole");
    	db.AddRoom(Integer.parseInt(selectCinema), room.getName(), room.getSeats());
     	return "redirect:/addRoom";
    }
  /*
    @GetMapping("/addShow")
    public String addShow(Model model) throws ClassNotFoundException, SQLException {
    	db=new DatabaseController("db_cbs", "springuser", "parole");
    	//model.addAttribute("room", db.getRooms(cinemaID));
    	model.addAttribute("movies", db.getFilmas());
        model.addAttribute("cinemas", db.getCinemas());
    	return "addShow";
    }
 
    @PostMapping(value = "/addShow")
    public String adminAddShow(@ModelAttribute Rooms room, Cinemas cinema, String selectCinema) throws ClassNotFoundException, SQLException{
    	//System.out.println(selectedCinema.getCinema_id());
    	db=new DatabaseController("db_cbs", "springuser", "parole");
    	db.AddRoom(Integer.parseInt(selectCinema), room.getName(), room.getSeats());
     	return "redirect:/addShow";
    }*/
    
    @GetMapping("/deleteCinema")
    public String deleteCinema(Model model) throws ClassNotFoundException, SQLException {
    	db=new DatabaseController("db_cbs", "springuser", "parole");
        model.addAttribute("cinemas", db.getCinemas());
    	return "deleteCinema";
    }
 
    @PostMapping(value = "/deleteCinema")
    public String adminDeleteCinema(@ModelAttribute Cinemas cinema, String selectCinema) throws ClassNotFoundException, SQLException{
    	System.out.println(Integer.parseInt(selectCinema));
    	db=new DatabaseController("db_cbs", "springuser", "parole");
    	db.DeleteCinema(Integer.parseInt(selectCinema));
     	return "redirect:/cinemaList";
    }
    
    @GetMapping("/deleteMovie")
    public String deleteMovie(Model model) throws ClassNotFoundException, SQLException {
    	db=new DatabaseController("db_cbs", "springuser", "parole");
        model.addAttribute("movies", db.getFilmas());
    	return "deleteMovie";
    }
 
    @PostMapping(value = "/deleteMovie")
    public String adminDeleteMovie(@ModelAttribute Cinemas cinema, String selectMovie) throws ClassNotFoundException, SQLException{
    	System.out.println(Integer.parseInt(selectMovie));
    	db=new DatabaseController("db_cbs", "springuser", "parole");
    	db.DeleteMovie(Integer.parseInt(selectMovie));
     	return "redirect:/getMovies";
    }
    @GetMapping("/deleteRoom")
    public String deleteRoom(@RequestParam(name="cinemaID", required=true, defaultValue="1") String cinemaID, Cinemas cinema, Model model) throws ClassNotFoundException, SQLException {
    	db=new DatabaseController("db_cbs", "springuser", "parole");
      	model.addAttribute("cinemas", db.getCinemas());
        model.addAttribute("rooms", db.getRooms(Integer.parseInt(cinemaID)));
    	return "deleteRoom";
    }
 
    @PostMapping(value = "/deleteRoom")
    public String adminDeleteRoom(@RequestParam(name="cinemaID", required=true, defaultValue="1") String cinemaID, Cinemas cinema, Model model) throws ClassNotFoundException, SQLException{
    	db=new DatabaseController("db_cbs", "springuser", "parole");
       	model.addAttribute("cinemas", db.getCinemas());
    	model.addAttribute("rooms", db.getRooms(Integer.parseInt(cinemaID)));
    	//db.DeleteRoom(Integer.parseInt(selectMovie));
     	return "/deleteRoom";
    }
    

    
    
    
    
 
}
