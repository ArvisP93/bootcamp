package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;



@Controller
public class Controllers {
	
	@RequestMapping(value = "/cinemaview", method = RequestMethod.GET)
	public String selectCinemaController(Model model) {
		
		List<Cinema> cinemalist = new ArrayList<>();
		cinemalist.add(new Cinema("Rio", "2344,5665"));
		cinemalist.add(new Cinema("Rio", "2344,5665"));
		cinemalist.add(new Cinema("Rio", "2344,5665"));
		cinemalist.add(new Cinema("Rio", "2344,5665"));
		cinemalist.add(new Cinema("Rio", "2344,5665"));
		
		List<Movie> movielist = new ArrayList<>();
		movielist.add(new Movie("Avengers", "Action", 125, "16+"));
		movielist.add(new Movie("Avengers", "Action", 125, "16+"));	
		movielist.add(new Movie("Avengers", "Action", 125, "16+"));
		
		model.addAttribute("cinemalist", cinemalist);
		
		return "cinemaview";
	}
	
}
